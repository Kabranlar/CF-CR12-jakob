	<?php wp_footer(); ?>
  <footer class="py-3 my-5">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Mount Everest GmbH 2020</p>
    </div>
    <!-- /.container -->
  </footer>
</body>

</html>