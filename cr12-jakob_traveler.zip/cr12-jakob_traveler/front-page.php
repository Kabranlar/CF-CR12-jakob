<?php get_header(); ?>

  <header class="text-white">
    <div class="container text-center">
      <h1>Welcome to your next destination</h1>
      <p class="lead text-center">Take a deep breath and let go</p>
    </div>
  </header>

  <section id="about" class="my-3">
    <div class="container">
      <div class="row blue">
        <div class="col-lg-8 mx-auto py-3">
          <h2>About this page</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
          quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
          consequat.</p>
          <ul>
            <li>Lorem ipsum dolor sit amet</li>
            <li>Sunt in culpa qui officia deserunt mollit anim id est laborum</li>
            <li>Ut enim ad minim veniam</li>
            <li>Duis aute irure dolor in reprehenderit in voluptate velit esse
            cillum dolore eu fugiat nulla pariatur</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <section id="services" class="my-3">
    <div class="container">
      <div class="row white">
        <div class="col-lg-8 mx-auto py-3">
          <h2>Services we offer</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut optio velit inventore, expedita quo laboriosam possimus ea consequatur vitae, doloribus consequuntur ex. Nemo assumenda laborum vel, labore ut velit dignissimos.</p>
        </div>
      </div>
    </div>
  </section>

  <section id="contact my-3">
    <div class="container">
      <div class="row blue">
        <div class="col-lg-8 mx-auto py-3">
          <h2>Contact us</h2>
          <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero odio fugiat voluptatem dolor, provident officiis, id iusto! Obcaecati incidunt, qui nihil beatae magnam et repudiandae ipsa exercitationem, in, quo totam.</p>
        </div>
      </div>
    </div>
  </section>

<?php get_footer(); ?>