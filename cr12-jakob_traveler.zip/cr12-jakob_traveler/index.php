<?php get_header(); ?>
   	<div class="container bgWhite">
   		<div class="row">
   			<div class="col-8">
				<h1>Blog</h1>
		       	<?php if(have_posts()) : ?> <!--  If there are posts available  -->

			       	<?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop -->

						<?php if(has_post_thumbnail()) : ?>
							<?php the_post_thumbnail('thumbnail'); ?>
						<?php endif; ?>

				       	<a href="<?php the_permalink(); ?>"><!--retrieves URL for the permalink-->
				      		<?php the_title(); ?>    <!--retrieves blog title-->
				   		</a>

				       	<p><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->

				       	<p> <?php the_author(); ?></p><!--retrieves author of blog entry-->

				       	<?php the_excerpt(); ?><!--retrieves excerpt-->

			       	<?php endwhile; ?><!--end the while loop-->

			       	<?php else :?> <!-- if no posts are found then: -->

			       		<p>No posts found</p>  <!-- no posts found displayed -->
		       	<?php endif; ?> <!-- end if -->
		    </div>
		    <div id="sidebar" class="col-4 d-none d-md-block">	<!-- sidebar with widgets -->
				<?php
					if(is_active_sidebar('sidebar')):
					dynamic_sidebar('sidebar');
					endif;  
				?>
			</div>
   		</div>
   	</div>
<?php get_footer(); ?>